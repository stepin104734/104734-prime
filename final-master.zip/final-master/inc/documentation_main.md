@mainpage Prime number Application by Santhosh Kumar
@subpage Prime number
